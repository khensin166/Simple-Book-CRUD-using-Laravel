

<?php $__env->startSection('title'); ?>
    Edit Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('update', ['id' => $buku->id])); ?>" method="post">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Judul Buku</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($buku->title); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Deskripsi Buku</label>
            <textarea class="form-control" id="description" name="description" rows="3" required><?php echo e($buku->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select class="form-control" id="status" name="status" required>
                <option value="active" <?php echo e($buku->status == 'active' ? 'selected' : ''); ?>>Aktif</option>
                <option value="inactive" <?php echo e($buku->status == 'inactive' ? 'selected' : ''); ?>>Non-Aktif</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\psw2\w12-Crud\resources\views/edit.blade.php ENDPATH**/ ?>