

<?php $__env->startSection('title'); ?>
    Kumpulan Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(Route('create')); ?>">
        <button class="btn btn-primary">Tambah Data</button>
    </a>
    <table class="table">
        <thead class="thead-light">
            <tr>
                <th scope="col">no</th>
                <th scope="col">Judul Buku</th>
                <th scope="col">Deskripsi Buku</th>
                <th scope="col">Status</th>
                <th scope="col">Dibuat</th>
                <th scope="col">Diedit</th>
                <th scope="col">action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($buku->title); ?></td>
                <td><?php echo e($buku->description); ?></td>
                <td><?php echo e($buku->status); ?></td>
                <td><?php echo e($buku->created_at); ?></td>
                <td><?php echo e($buku->updated_at); ?></td>
                <td>
                    <form action="<?php echo e(route('edit', ['id' => $buku->id])); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-primary">Edit</button>
                    </form>
                    <form action="<?php echo e(route('delete', ['id' => $buku->id])); ?>" method="POST">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-warning">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\psw2\w12-Crud\resources\views/index.blade.php ENDPATH**/ ?>